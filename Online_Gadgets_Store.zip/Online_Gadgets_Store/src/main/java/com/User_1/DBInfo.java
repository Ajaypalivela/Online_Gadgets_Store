package com.User_1;

public interface DBInfo 
{
	public static final  String DBUrl="jdbc:oracle:thin:@localhost:1521:orcl";
	public static final  String DBUname="adv";
	public static final  String DBUpwd="adv";
}
